# FitnessApp

A Java-based fitness activity tracker demonstrating OOP, JDBC, and multithreading.

### Prepared by:
**GARV SHARMA, SURYANSH PRATAP SINGH AND DIVYANSHU SINGH**

## Repo Structure
```
src/main/java/           # Java source files
sql/                     # Database schema
docs/                    # Presentation
backup/                  # Auto backup folder
pom.xml                  # Maven build file
run.sh                   # Run script
README.md
```

## Environment Variables
```bash
export DB_URL=jdbc:mysql://localhost:3306/fitness_db
export DB_USER=root
export DB_PASS=yourpassword
```

## Build & Run
```bash
mvn clean package
./run.sh
```
