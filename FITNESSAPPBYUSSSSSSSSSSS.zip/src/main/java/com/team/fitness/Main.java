package com.team.fitness;

import java.io.File;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

public class Main {
    public static void main(String[] args) {
        System.out.println("FitnessApp Started by: GARV SHARMA, SURYANSH PRATAP SINGH AND DIVYANSHU SINGH");

        List<Activity> activities = new CopyOnWriteArrayList<>();
        try {
            activities.add(new StepsActivity("Walk", 3000));
            activities.add(new RunningActivity("Run", 2.5));
            activities.add(new CyclingActivity("Ride", 10));
        } catch (Exception e) { System.out.println(e.getMessage()); }

        DatabaseHandler db = DatabaseHandler.getInstance();
        activities.forEach(db::insertActivity);

        new File("backup").mkdirs();
        new Thread(new AutoBackupThread(activities, "backup/backup.csv")).start();

        LiveStepCounterThread step = new LiveStepCounterThread();
        step.start();

        System.out.println("App Running...");
    }
}
