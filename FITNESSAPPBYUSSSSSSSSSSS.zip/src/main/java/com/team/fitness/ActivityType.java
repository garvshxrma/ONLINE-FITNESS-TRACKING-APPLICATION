package com.team.fitness;

public enum ActivityType { STEPS, RUNNING, CYCLING }