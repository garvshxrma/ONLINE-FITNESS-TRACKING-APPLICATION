package com.team.fitness;

import java.io.*;
import java.util.*;

public class AutoBackupThread implements Runnable {
    private final List<Activity> activities;
    private volatile boolean running = true;
    private final String backupFile;

    public AutoBackupThread(List<Activity> list, String backupFile) {
        this.activities = list;
        this.backupFile = backupFile;
    }

    @Override public void run() {
        while (running && !Thread.currentThread().isInterrupted()) {
            backup();
            try { Thread.sleep(5000); }
            catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        }
    }

    private void backup() {
        try (PrintWriter pw = new PrintWriter(new FileWriter(backupFile))) {
            for (Activity a : activities)
                pw.println(a.getName() + "," + a.getType() + "," + a.calculateCalories());
            System.out.println("Backup saved");
        } catch (Exception e) {
            System.err.println("Backup error " + e.getMessage());
        }
    }

    public void stopThread() { running = false; }
}