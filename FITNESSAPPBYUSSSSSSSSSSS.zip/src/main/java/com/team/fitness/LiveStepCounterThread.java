package com.team.fitness;

public class LiveStepCounterThread extends Thread {
    private int steps = 0;
    private volatile boolean running = true;

    @Override
    public void run() {
        while (running && !Thread.currentThread().isInterrupted()) {
            steps++;
            try { Thread.sleep(1000); }
            catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        }
    }

    public int getSteps() { return steps; }

    public void stopCounter() { running = false; this.interrupt(); }
}