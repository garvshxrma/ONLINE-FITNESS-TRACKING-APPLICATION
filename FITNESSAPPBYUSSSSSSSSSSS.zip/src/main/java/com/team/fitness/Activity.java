package com.team.fitness;

public abstract class Activity implements IActivity {
    protected final String name;
    protected final ActivityType type;

    public Activity(String name, ActivityType type) throws InvalidInputException {
        if (name == null || name.trim().isEmpty())
            throw new InvalidInputException("Name cannot be empty");
        this.name = name.trim();
        this.type = type;
    }

    public String getName() { return name; }
    public ActivityType getType() { return type; }

    @Override
    public String toString() { return name + " (" + type + ")"; }
}