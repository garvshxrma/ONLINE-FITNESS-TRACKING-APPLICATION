package com.team.fitness;

public class CyclingActivity extends Activity {
    private final double distance;
    public CyclingActivity(String name, double distance) throws InvalidInputException {
        super(name, ActivityType.CYCLING);
        if (distance < 0) throw new InvalidInputException("Distance cannot be negative");
        this.distance = distance;
    }
    @Override public double calculateCalories() { return distance * 30.0; }
}