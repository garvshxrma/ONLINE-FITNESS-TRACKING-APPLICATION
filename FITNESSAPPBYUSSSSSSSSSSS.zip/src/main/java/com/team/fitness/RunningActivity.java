package com.team.fitness;

public class RunningActivity extends Activity {
    private final double distance;
    public RunningActivity(String name, double distance) throws InvalidInputException {
        super(name, ActivityType.RUNNING);
        if (distance < 0) throw new InvalidInputException("Distance cannot be negative");
        this.distance = distance;
    }
    @Override public double calculateCalories() { return distance * 60.0; }
}