package com.team.fitness;

public class StepsActivity extends Activity {
    private final int steps;
    public StepsActivity(String name, int steps) throws InvalidInputException {
        super(name, ActivityType.STEPS);
        if (steps < 0) throw new InvalidInputException("Steps cannot be negative");
        this.steps = steps;
    }
    @Override public double calculateCalories() { return steps * 0.04; }
}