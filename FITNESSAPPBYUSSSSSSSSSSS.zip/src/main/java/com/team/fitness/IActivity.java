package com.team.fitness;

public interface IActivity { double calculateCalories(); }