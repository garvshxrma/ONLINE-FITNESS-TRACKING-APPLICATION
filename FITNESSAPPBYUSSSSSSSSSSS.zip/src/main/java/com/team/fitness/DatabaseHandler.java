package com.team.fitness;

import java.sql.*;
import java.util.*;

public class DatabaseHandler {
    private static DatabaseHandler instance;
    private Connection conn;

    private DatabaseHandler() { connect(); }

    public static synchronized DatabaseHandler getInstance() {
        if (instance == null) instance = new DatabaseHandler();
        return instance;
    }

    private void connect() {
        try {
            String url = System.getenv().getOrDefault("DB_URL", "jdbc:mysql://localhost:3306/fitness_db");
            String user = System.getenv().getOrDefault("DB_USER", "root");
            String pass = System.getenv().getOrDefault("DB_PASS", "");

            conn = DriverManager.getConnection(url, user, pass);
            System.out.println("DB Connected Successfully!");
        } catch (SQLException e) {
            System.err.println("DB Error: " + e.getMessage());
            conn = null;
        }
    }

    public synchronized void insertActivity(Activity a) {
        if (conn == null) return;
        String sql = "INSERT INTO activities(name, type, calories) VALUES (?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, a.getName());
            ps.setString(2, a.getType().toString());
            ps.setDouble(3, a.calculateCalories());
            ps.executeUpdate();
            System.out.println("Saved: " + a);
        } catch (SQLException e) {
            System.err.println("Insert Error: " + e.getMessage());
        }
    }
}
