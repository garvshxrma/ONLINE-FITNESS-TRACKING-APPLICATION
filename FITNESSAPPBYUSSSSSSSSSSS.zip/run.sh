#!/bin/bash
mvn -q clean package
export DB_URL=${DB_URL:-jdbc:mysql://localhost:3306/fitness_db}
export DB_USER=${DB_USER:-root}
export DB_PASS=${DB_PASS:-}
java -cp target/FitnessApp-1.0-SNAPSHOT.jar com.team.fitness.Main
